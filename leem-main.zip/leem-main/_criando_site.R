# Configurando o pacote para pkgdonw
usethis::use_pkgdown()
# Criando site
pkgdown::build_site()
