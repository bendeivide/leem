# crayon package

warn <- crayon::green$bold
note <- crayon::cyan
error <- crayon::red$bold
