# Global variables

if (getRversion() >= "2.15.1") {
  utils::globalVariables(c("tk_q1", "tk_q2", "tk_df"))
}



