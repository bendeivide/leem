# comandos para internacionalizacao

## Criando os diretorios para .po
tools::update_pkg_po()

## Checagem de arquivos po
tools::checkPoFile()
tools::checkPoFiles()

## Extrai mensagens traduzidas
tools::xgettext()
tools::xgettext2pot()
tools::xngettext()

## Funcoes para traducao
base::gettext()
base::ngettext()
base::bindtextdomain()
